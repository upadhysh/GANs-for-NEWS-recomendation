## ltr-gan-pointwise
+ You should download the data set from [here](https://drive.google.com/drive/folders/0B-dulzPp3MmCM01kYlhhNGQ0djA?usp=sharing), and then put in `MQ2008-semi/`.
+ Run `python run.py` to evaluate the stored models.