# IRGAN

This repository hosts the experimental code for SIGIR 2017 paper "IRGAN: A Minimax Game for Unifying Generative and Discriminative Information Retrieval Models".

More detailed instructions will be provided soon.

For any questions, you can report issue here.
